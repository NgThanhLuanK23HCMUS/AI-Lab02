change your working directory to Source:
cd Source
install requirements:
pipe install -r requirements.txt
Execute the script with:
python main.py